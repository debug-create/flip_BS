"""DRISHTI FastAPI backend — traffic violation detection pipeline."""

from __future__ import annotations

import logging
import math
import os
import tempfile
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

# Load .env from backend directory before any pipeline imports read env vars
load_dotenv(Path(__file__).resolve().parent / ".env")

import cv2
import numpy as np
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image

from pipeline.annotate import annotate_image
from pipeline.detect import VIOLATION_TYPES, get_detector
from pipeline.evidence import aggregate_violation_breakdown, build_evidence_package
from pipeline.ocr import PlateOCR

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("drishti")

MAX_FILE_SIZE_BYTES = 50 * 1024 * 1024
MAX_VIDEO_SECONDS = 30
VIDEO_SAMPLE_FPS = 2

ALLOWED_IMAGE_TYPES = {
    "image/jpeg": {".jpg", ".jpeg"},
    "image/png": {".png"},
    "image/webp": {".webp"},
}
ALLOWED_VIDEO_TYPES = {
    "video/mp4": {".mp4"},
    "video/x-msvideo": {".avi"},
    "video/avi": {".avi"},
}

VIOLATION_DESCRIPTIONS = {
    "Helmet Non-Compliance": "Rider without a helmet on a two-wheeler.",
    "Seatbelt Non-Compliance": "Vehicle occupant not wearing a seatbelt.",
    "Triple Riding": "More than two persons on a single two-wheeler.",
    "Wrong-Side Driving": "Vehicle traveling against permitted traffic flow.",
    "Stop-Line Violation": "Vehicle crossed the stop line before signal clearance.",
    "Red-Light Running": "Vehicle entered junction during red signal phase.",
    "Illegal Parking": "Vehicle parked in a no-parking or obstructive zone.",
    "Defective/Missing Plate": "License plate missing, obscured, or unreadable.",
}

detector = None
plate_ocr: PlateOCR | None = None


@asynccontextmanager
async def lifespan(_: FastAPI):
    global detector, plate_ocr

    detector = get_detector()
    plate_ocr = PlateOCR()
    logger.info("DRISHTI backend ready — Roboflow 3-model pipeline + EasyOCR active.")
    yield


app = FastAPI(
    title="DRISHTI API",
    description="Traffic violation detection backend for Bengaluru Traffic Police",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _get_extension(filename: str | None) -> str:
    if not filename or "." not in filename:
        return ""
    return "." + filename.rsplit(".", 1)[-1].lower()


def _validate_file_size(file_bytes: bytes) -> None:
    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        raise HTTPException(status_code=413, detail="File too large. Maximum allowed size is 50MB.")


def _validate_image_upload(file: UploadFile, file_bytes: bytes) -> None:
    extension = _get_extension(file.filename)
    content_type = (file.content_type or "").lower()

    allowed_exts = set().union(*ALLOWED_IMAGE_TYPES.values())
    if extension not in allowed_exts and content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(
            status_code=415,
            detail="Unsupported image type. Allowed formats: jpg, jpeg, png, webp.",
        )

    try:
        Image.open(BytesIO(file_bytes)).verify()
    except Exception as exc:
        raise HTTPException(status_code=415, detail="Invalid or corrupted image file.") from exc


def _validate_video_upload(file: UploadFile, file_bytes: bytes) -> None:
    extension = _get_extension(file.filename)
    content_type = (file.content_type or "").lower()

    allowed_exts = set().union(*ALLOWED_VIDEO_TYPES.values())
    if extension not in allowed_exts and content_type not in ALLOWED_VIDEO_TYPES:
        raise HTTPException(
            status_code=415,
            detail="Unsupported video type. Allowed formats: mp4, avi.",
        )


def _decode_image(file_bytes: bytes) -> np.ndarray:
    image_array = np.frombuffer(file_bytes, dtype=np.uint8)
    image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
    if image is None:
        raise HTTPException(status_code=415, detail="Unable to decode image file.")
    return image


def _run_image_pipeline(image: np.ndarray, source_filename: str) -> dict[str, Any]:
    if detector is None or plate_ocr is None:
        raise HTTPException(status_code=500, detail="Inference services are not initialized.")

    start = time.perf_counter()

    try:
        detections = detector.detect(image)

        for det in detections:
            plate_bbox = det.pop("plate_bbox", None)
            det.pop("violation_confidence", None)

            if plate_bbox:
                det["plate"] = plate_ocr.extract_plate(image, plate_bbox)
            else:
                det["plate"] = {"plate_text": "UNDETECTED", "confidence": 0.0, "raw_ocr": ""}

        # Flag missing/undetected plates as violations
        # Only flag UNDETECTED (plate model found nothing)
        # NOT UNREADABLE (plate found but OCR failed — could be angle/blur)
        for det in detections:
            plate = det.get("plate") or {}
            plate_text = plate.get("plate_text", "")

            if not det["is_violation"] and plate_text == "UNDETECTED":
                det["is_violation"] = True
                det["violation_type"] = "Defective/Missing Plate"
                det["violation_confidence"] = 0.75

        plates = [det["plate"] for det in detections]
        annotated = annotate_image(image, detections, plates)
        inference_time_ms = (time.perf_counter() - start) * 1000

        return build_evidence_package(
            original_image=image,
            annotated_image=annotated,
            detections=detections,
            plates=plates,
            source_filename=source_filename,
            inference_time_ms=inference_time_ms,
            model_version=detector.model_version,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Image inference failed")
        raise HTTPException(status_code=500, detail=f"Inference failed: {exc}") from exc


def _extract_video_frames(file_bytes: bytes) -> list[np.ndarray]:
    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as temp_file:
        temp_file.write(file_bytes)
        temp_path = temp_file.name

    capture = cv2.VideoCapture(temp_path)
    if not capture.isOpened():
        raise HTTPException(status_code=415, detail="Unable to open video file.")

    fps = capture.get(cv2.CAP_PROP_FPS) or 25.0
    frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration_seconds = frame_count / fps if frame_count > 0 else 0

    if duration_seconds > MAX_VIDEO_SECONDS:
        capture.release()
        raise HTTPException(
            status_code=413,
            detail=f"Video too long. Maximum allowed duration is {MAX_VIDEO_SECONDS} seconds.",
        )

    frame_interval = max(1, int(round(fps / VIDEO_SAMPLE_FPS)))
    frames: list[np.ndarray] = []
    frame_index = 0

    while True:
        success, frame = capture.read()
        if not success:
            break
        if frame_index % frame_interval == 0:
            frames.append(frame)
        frame_index += 1

    capture.release()

    try:
        os.remove(temp_path)
    except OSError:
        pass

    if not frames:
        raise HTTPException(status_code=415, detail="No frames could be extracted from video.")

    return frames


@app.get("/health")
def health() -> dict[str, str]:
    return {
        "status": "ok",
        "model": "roboflow-3model",
        "mode": "PRODUCTION",
    }


@app.get("/violations/types")
def violation_types() -> list[dict[str, str]]:
    return [
        {"name": name, "description": VIOLATION_DESCRIPTIONS[name]}
        for name in VIOLATION_TYPES
    ]


@app.post("/analyze/image")
async def analyze_image(file: UploadFile = File(...)) -> dict[str, Any]:
    file_bytes = await file.read()
    _validate_file_size(file_bytes)
    _validate_image_upload(file, file_bytes)

    image = _decode_image(file_bytes)
    return _run_image_pipeline(image, file.filename or "uploaded_image")


@app.post("/analyze/video")
async def analyze_video(file: UploadFile = File(...)) -> dict[str, Any]:
    file_bytes = await file.read()
    _validate_file_size(file_bytes)
    _validate_video_upload(file, file_bytes)

    frames = _extract_video_frames(file_bytes)
    timeline: list[dict[str, Any]] = []
    total_violations = 0

    for frame_index, frame in enumerate(frames, start=1):
        frame_name = f"{file.filename or 'uploaded_video'}#frame_{frame_index}"
        evidence = _run_image_pipeline(frame, frame_name)
        timeline.append(evidence)
        total_violations += evidence["summary"]["total_violations_detected"]

    return {
        "total_frames_analyzed": len(timeline),
        "total_violations_found": total_violations,
        "violation_timeline": timeline,
        "aggregate_violation_breakdown": aggregate_violation_breakdown(timeline),
    }


# ---------------------------------------------------------------------------
# STATIC REFERENCE DATA — Bengaluru junctions (BTP black-spot list)
# ---------------------------------------------------------------------------

_JUNCTIONS = [
    {"name": "Silk Board Junction",    "lat": 12.9165, "lon": 77.6229, "base_risk": 90, "violation_type": "Signal + Helmet"},
    {"name": "KR Puram Bridge",        "lat": 13.0050, "lon": 77.6952, "base_risk": 85, "violation_type": "Helmet + Wrong Side"},
    {"name": "Whitefield Junction",    "lat": 12.9698, "lon": 77.7499, "base_risk": 82, "violation_type": "Signal + Triple Riding"},
    {"name": "Marathahalli Bridge",    "lat": 12.9560, "lon": 77.6978, "base_risk": 78, "violation_type": "Helmet + Parking"},
    {"name": "Hebbal Flyover",         "lat": 13.0358, "lon": 77.5991, "base_risk": 74, "violation_type": "Signal + Seatbelt"},
    {"name": "Tin Factory Junction",   "lat": 13.0120, "lon": 77.6572, "base_risk": 70, "violation_type": "Helmet"},
    {"name": "Indiranagar 100ft Rd",   "lat": 12.9784, "lon": 77.6408, "base_risk": 66, "violation_type": "Parking + Wrong Side"},
    {"name": "Koramangala 80ft Rd",    "lat": 12.9352, "lon": 77.6245, "base_risk": 62, "violation_type": "Triple Riding"},
]

_FLEET_CORRIDORS = [
    {"zone": "ORR Corridor",  "riders": 524, "base_incidents": 21},
    {"zone": "Whitefield",    "riders": 412, "base_incidents": 18},
    {"zone": "KR Puram",      "riders": 286, "base_incidents": 9},
    {"zone": "Indiranagar",   "riders": 218, "base_incidents": 3},
]

_FLEET_ROUTES = [
    {"route": "Whitefield → Marathahalli", "base_incidents": 14},
    {"route": "KR Puram → Indiranagar",    "base_incidents": 9},
    {"route": "Koramangala → HSR",         "base_incidents": 6},
    {"route": "Bellandur → Sarjapur",      "base_incidents": 4},
    {"route": "Hebbal → Yeshwanthpur",     "base_incidents": 2},
]

_FLEET_RECS: dict[str, list[str]] = {
    "morning_peak": [
        "Deploy helmet-check marshals at Whitefield hub before 8 AM",
        "Alert riders on ORR corridor: AI cameras active — signal violations up 28%",
        "Pre-position BTP at KR Puram bridge for shift-change congestion",
        "Push notification to all active riders: helmet compliance mandatory",
    ],
    "evening_peak": [
        "Increase monitoring on ORR corridor during 6–9 PM window",
        "Launch helmet awareness push notification to active riders",
        "Reroute night shift around Silk Board congestion zone",
        "Target helmet compliance audit at KR Puram dispatch hub",
    ],
    "midday": [
        "Run helmet compliance audit at Whitefield and Marathahalli hubs",
        "Update rider routing to avoid ORR corridor (risk elevated)",
        "Review flagged riders from morning peak with dispatch managers",
        "Coordinate with BTP on Indiranagar 100ft Road enforcement window",
    ],
    "off_peak": [
        "Good window to conduct rider briefing on updated traffic rules",
        "Review last 7-day violation data with dispatch managers",
        "Inspect fleet vehicles for helmet and seatbelt availability",
        "Prepare route recommendations based on next-day congestion forecast",
    ],
}


def _ist_hour() -> int:
    """Current hour in IST (UTC+5:30)."""
    now = datetime.now(timezone.utc)
    return ((now.hour * 60 + now.minute + 330) // 60) % 24


def _peak_period() -> str:
    h = _ist_hour()
    if 7 <= h <= 10:
        return "morning_peak"
    if 17 <= h <= 20:
        return "evening_peak"
    if 11 <= h <= 16:
        return "midday"
    return "off_peak"


def _time_multiplier() -> float:
    """Risk multiplier relative to baseline (1.0) driven by IST hour."""
    h = _ist_hour()
    if 7 <= h <= 10:
        return 1.4 + 0.1 * math.sin((h - 7) / 3.0 * math.pi)
    if 17 <= h <= 20:
        return 1.35 + 0.1 * math.sin((h - 17) / 3.0 * math.pi)
    if 11 <= h <= 16:
        return 1.1
    if h in (6, 21, 22):
        return 1.2
    return 0.7  # night


# ---------------------------------------------------------------------------
# PREDICT — hotspot forecasting
# ---------------------------------------------------------------------------

@app.get("/predict/hotspots")
def predict_hotspots() -> dict[str, Any]:
    """
    Rule-based 30–60 min violation hotspot forecast.
    Uses IST time-of-day multipliers applied to known BTP black-spot base scores.
    """
    mult = _time_multiplier()
    period = _peak_period()
    pct_vs_baseline = round((mult - 1.0) * 100)
    delta_str = f"+{pct_vs_baseline}%" if pct_vs_baseline >= 0 else f"{pct_vs_baseline}%"

    hotspots = []
    for i, j in enumerate(_JUNCTIONS):
        jitter = (((i * 7 + 3) % 13) - 6) * 0.5
        risk = min(99, max(30, round(j["base_risk"] * mult + jitter)))
        eta = "Now" if risk >= 87 else "20 min" if risk >= 76 else "40 min" if risk >= 65 else "60 min"
        hotspots.append({
            "name": j["name"],
            "lat": j["lat"],
            "lon": j["lon"],
            "risk": risk,
            "eta": eta,
            "delta": delta_str,
            "violation_type": j["violation_type"],
        })
    hotspots.sort(key=lambda x: x["risk"], reverse=True)

    officer_deployment = []
    for hs in hotspots[:4]:
        urgency = "Critical" if hs["risk"] >= 85 else "High" if hs["risk"] >= 70 else "Medium"
        officers = 3 if urgency == "Critical" else 2 if urgency == "High" else 1
        parts = hs["name"].split()
        officer_deployment.append({
            "junction": " ".join(parts[:2]),
            "officers": officers,
            "urgency": urgency,
        })

    ai_recommendations = []
    for i, hs in enumerate(hotspots[:4]):
        priority = "CRITICAL" if hs["risk"] >= 85 else "HIGH" if hs["risk"] >= 75 else "MEDIUM"
        pct_j = pct_vs_baseline + i * 3
        ai_recommendations.append({
            "title": f"{hs['name']} violation probability +{pct_j}%",
            "priority": priority,
            "confidence": min(98, hs["risk"] + 6),
            "action": "Dispatch 2 units" if hs["risk"] >= 85 else "Pre-position patrol",
            "eta": hs["eta"],
            "junction": hs["name"].split()[0],
        })

    _forecast_base: dict[str, dict[str, str]] = {
        "morning_peak": {"helmet": "+28%", "signal": "+19%", "wrong_side": "+12%", "orr": "+22%"},
        "evening_peak": {"helmet": "+23%", "signal": "+14%", "wrong_side": "+9%",  "orr": "+18%"},
        "midday":       {"helmet": "+8%",  "signal": "+5%",  "wrong_side": "+3%",  "orr": "+4%"},
        "off_peak":     {"helmet": "-12%", "signal": "-8%",  "wrong_side": "-5%",  "orr": "-3%"},
    }
    fc = _forecast_base[period]
    ai_forecast = [
        {"label": "Helmet violations",   "change": fc["helmet"],     "horizon": "Next 60 min", "confidence": 92},
        {"label": "Signal violations",   "change": fc["signal"],     "horizon": "Next 45 min", "confidence": 88},
        {"label": "Wrong-side driving",  "change": fc["wrong_side"], "horizon": "Next 30 min", "confidence": 84},
        {"label": "Overspeeding (ORR)",  "change": fc["orr"],        "horizon": "Next 90 min", "confidence": 81},
    ]

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "period": period,
        "time_multiplier": round(mult, 3),
        "hotspots": hotspots,
        "officer_deployment": officer_deployment,
        "ai_recommendations": ai_recommendations,
        "ai_forecast": ai_forecast,
    }


# ---------------------------------------------------------------------------
# FLEET — delivery operator intelligence (Flipkart tenant view)
# ---------------------------------------------------------------------------

@app.get("/fleet/summary")
def fleet_summary() -> dict[str, Any]:
    """Fleet safety telemetry for delivery operators."""
    mult = _time_multiplier()
    period = _peak_period()

    safety_score = round(max(70.0, min(98.0, 89.0 - (mult - 1.0) * 15)), 1)
    flagged = round(36 * mult)

    corridors = []
    for c in _FLEET_CORRIDORS:
        incidents = round(c["base_incidents"] * mult)
        risk = "High" if incidents >= 15 else "Medium" if incidents >= 8 else "Low"
        corridors.append({"zone": c["zone"], "riders": c["riders"], "incidents": incidents, "risk": risk})
    corridors.sort(key=lambda x: x["incidents"], reverse=True)

    top_routes = []
    for r in _FLEET_ROUTES:
        incidents = round(r["base_incidents"] * mult)
        risk = "High" if incidents >= 12 else "Medium" if incidents >= 7 else "Low"
        top_routes.append({"route": r["route"], "incidents": incidents, "risk": risk})

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "period": period,
        "summary": {
            "safety_score": safety_score,
            "active_riders": 1248,
            "flagged_this_week": flagged,
        },
        "delivery_corridors": corridors,
        "top_routes": top_routes,
        "safety_recommendations": _FLEET_RECS[period],
    }


# ---------------------------------------------------------------------------
# COMMAND — KPIs, top junctions, repeat offenders, AI recommendations
# ---------------------------------------------------------------------------

@app.get("/command/summary")
def command_summary() -> dict[str, Any]:
    """Command Center live intelligence: KPIs, junction rankings, watchlist, AI recs."""
    mult = _time_multiplier()
    period = _peak_period()

    kpi = {
        "activeCameras": 312,
        "totalCameras": 340,
        "predictionAccuracy": 94.3,
        "highRiskJunctions": round(8 + (mult - 0.7) * 9),
    }

    top_junctions = []
    for i, j in enumerate(_JUNCTIONS[:8]):
        jitter = (((i * 7 + 3) % 13) - 6) * 0.5
        violations = max(50, round((420 - i * 38) * mult + jitter * 5))
        risk_score = min(99, round(j["base_risk"] * mult))
        risk = "Critical" if risk_score >= 85 else "High" if risk_score >= 70 else "Medium" if risk_score >= 50 else "Low"
        top_junctions.append({"junction": j["name"], "violations": violations, "risk": risk})
    top_junctions.sort(key=lambda x: x["violations"], reverse=True)

    repeat_offenders = [
        {"plate": "KA03MJ1234", "score": 92, "count": 14, "lastSeen": "KR Puram",    "type": "Helmet"},
        {"plate": "KA05AB7890", "score": 88, "count": 11, "lastSeen": "Whitefield",  "type": "Wrong Side"},
        {"plate": "KA01XY6789", "score": 84, "count": 9,  "lastSeen": "Silk Board",  "type": "Signal Jump"},
        {"plate": "KA51MZ4421", "score": 79, "count": 8,  "lastSeen": "Indiranagar", "type": "Triple Riding"},
        {"plate": "KA09HN7782", "score": 74, "count": 6,  "lastSeen": "Hebbal",      "type": "Helmet"},
    ]

    ai_recommendations = []
    for i, j in enumerate(_JUNCTIONS[:4]):
        jitter = (((i * 7 + 3) % 13) - 6) * 0.5
        risk = min(99, round(j["base_risk"] * mult + jitter))
        priority = "CRITICAL" if risk >= 85 else "HIGH" if risk >= 75 else "MEDIUM"
        pct = round((mult - 1.0) * 100) + i * 3
        parts = j["name"].split()
        ai_recommendations.append({
            "title": f"{j['name']} violation probability +{pct}%",
            "priority": priority,
            "confidence": min(98, risk + 6),
            "action": "Dispatch 2 units" if risk >= 85 else "Pre-position patrol",
            "eta": "Now" if risk >= 87 else "12 min" if risk >= 75 else "25 min",
            "junction": parts[0],
        })

    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "period": period,
        "kpi": kpi,
        "top_junctions": top_junctions,
        "repeat_offenders": repeat_offenders,
        "ai_recommendations": ai_recommendations,
    }


# ---------------------------------------------------------------------------
# DEBUG ROUTES — remove before production / demo day
# ---------------------------------------------------------------------------

@app.post("/debug/image")
async def debug_image(file: UploadFile = File(...)) -> dict[str, Any]:
    """Debug route — returns raw Roboflow predictions without post-processing."""
    file_bytes = await file.read()
    image = _decode_image(file_bytes)

    det = get_detector()
    h, w = image.shape[:2]

    # Stage 1: raw vehicle predictions
    from pipeline.detect import VEHICLE_MODEL, HELMET_MODEL, PLATE_MODEL

    vehicle_raw = det._call_roboflow(image, VEHICLE_MODEL)

    # Stage 2: run helmet model on first two-wheeler crop (if any)
    helmet_debug = []
    for vp in vehicle_raw:
        cls = vp.get("class", "").lower()
        is_tw = any(tw in cls for tw in ["motorcycle", "bike", "motorbike", "scooter", "two-wheeler"])
        if is_tw:
            bbox = det._pred_to_xyxy(vp)
            crop, _, _ = det._crop_with_padding(image, bbox, pad=20)
            if crop.size > 0:
                helmet_raw = det._call_roboflow(crop, HELMET_MODEL)
                helmet_debug.append({
                    "parent_vehicle": vp,
                    "crop_shape": list(crop.shape),
                    "helmet_predictions": helmet_raw,
                })

    # Stage 3: run plate model on first vehicle crop
    plate_debug = []
    for vp in vehicle_raw[:3]:  # limit to first 3 to avoid timeouts
        bbox = det._pred_to_xyxy(vp)
        crop, _, _ = det._crop_with_padding(image, bbox, pad=5)
        if crop.size > 0:
            plate_raw = det._call_roboflow(crop, PLATE_MODEL)
            plate_debug.append({
                "parent_vehicle": vp,
                "crop_shape": list(crop.shape),
                "plate_predictions": plate_raw,
            })

    return {
        "image_shape": [h, w, image.shape[2] if len(image.shape) > 2 else 1],
        "vehicle_model": VEHICLE_MODEL,
        "vehicle_raw_predictions": vehicle_raw,
        "vehicle_prediction_count": len(vehicle_raw),
        "helmet_debug": helmet_debug,
        "plate_debug": plate_debug,
    }


@app.get("/debug/models")
def debug_models() -> dict[str, Any]:
    """Check Roboflow API key validity and model connectivity."""
    from pipeline.detect import VEHICLE_MODEL, HELMET_MODEL, PLATE_MODEL, ROBOFLOW_API_KEY, ROBOFLOW_URL

    key_preview = ROBOFLOW_API_KEY[:6] + "..." if len(ROBOFLOW_API_KEY) > 6 else "(empty)"
    results = {"api_key_preview": key_preview, "roboflow_url": ROBOFLOW_URL, "models": {}}

    # Create a tiny test image (10x10 black square)
    test_img = np.zeros((10, 10, 3), dtype=np.uint8)
    det = get_detector()

    for name, model_id in [("vehicle", VEHICLE_MODEL), ("helmet", HELMET_MODEL), ("plate", PLATE_MODEL)]:
        try:
            preds = det._call_roboflow(test_img, model_id)
            results["models"][name] = {
                "model_id": model_id,
                "status": "ok",
                "test_predictions": len(preds),
            }
        except Exception as e:
            results["models"][name] = {
                "model_id": model_id,
                "status": "error",
                "error": str(e),
            }

    return results
