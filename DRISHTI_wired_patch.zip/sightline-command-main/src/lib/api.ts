import type {
  EvidencePackage,
  HealthResponse,
  VideoAnalysisResult,
  ViolationTypeInfo,
} from "./types";

const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:8000";

export class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    const detail =
      typeof body.detail === "string"
        ? body.detail
        : `Request failed (${response.status})`;
    throw new ApiError(detail, response.status);
  }
  return response.json() as Promise<T>;
}

export function getApiBase(): string {
  return API_BASE;
}

// ── existing endpoints ────────────────────────────────────────────────────

export async function getHealth(): Promise<HealthResponse> {
  const response = await fetch(`${API_BASE}/health`);
  return handleResponse<HealthResponse>(response);
}

export async function getViolationTypes(): Promise<ViolationTypeInfo[]> {
  const response = await fetch(`${API_BASE}/violations/types`);
  return handleResponse<ViolationTypeInfo[]>(response);
}

export async function analyzeImage(file: File): Promise<EvidencePackage> {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${API_BASE}/analyze/image`, {
    method: "POST",
    body: formData,
  });

  return handleResponse<EvidencePackage>(response);
}

export async function analyzeVideo(file: File): Promise<VideoAnalysisResult> {
  const formData = new FormData();
  formData.append("file", file);

  const response = await fetch(`${API_BASE}/analyze/video`, {
    method: "POST",
    body: formData,
  });

  return handleResponse<VideoAnalysisResult>(response);
}

export function annotatedImageSrc(b64: string): string {
  return `data:image/jpeg;base64,${b64}`;
}

export function formatApiError(error: unknown): string {
  if (error instanceof ApiError) {
    if (error.status === 413) return "File too large. Maximum size is 50 MB.";
    if (error.status === 415) return "Unsupported file format.";
    if (error.status === 500) return "Analysis failed. Try another image.";
    return error.message;
  }
  if (error instanceof Error) return error.message;
  return "An unexpected error occurred.";
}

// ── new endpoints ─────────────────────────────────────────────────────────

export interface ModelStatus {
  model_id: string;
  status: "ok" | "error";
  test_predictions?: number;
  error?: string;
}

export interface ModelHealthResponse {
  api_key_preview: string;
  roboflow_url: string;
  models: {
    vehicle: ModelStatus;
    helmet: ModelStatus;
    plate: ModelStatus;
  };
}

export interface HotspotItem {
  name: string;
  lat: number;
  lon: number;
  risk: number;
  eta: string;
  delta: string;
  violation_type: string;
}

export interface OfficerDeployment {
  junction: string;
  officers: number;
  urgency: string;
}

export interface AiRecommendation {
  title: string;
  priority: string;
  confidence: number;
  action: string;
  eta: string;
  junction: string;
}

export interface AiForecastItem {
  label: string;
  change: string;
  horizon: string;
  confidence: number;
}

export interface HotspotsResponse {
  generated_at: string;
  period: string;
  time_multiplier: number;
  hotspots: HotspotItem[];
  officer_deployment: OfficerDeployment[];
  ai_recommendations: AiRecommendation[];
  ai_forecast: AiForecastItem[];
}

export interface FleetSummary {
  safety_score: number;
  active_riders: number;
  flagged_this_week: number;
}

export interface DeliveryCorridor {
  zone: string;
  riders: number;
  incidents: number;
  risk: string;
}

export interface FleetRoute {
  route: string;
  incidents: number;
  risk: string;
}

export interface FleetSummaryResponse {
  generated_at: string;
  period: string;
  summary: FleetSummary;
  delivery_corridors: DeliveryCorridor[];
  top_routes: FleetRoute[];
  safety_recommendations: string[];
}

export interface CommandKpi {
  activeCameras: number;
  totalCameras: number;
  predictionAccuracy: number;
  highRiskJunctions: number;
}

export interface JunctionRanking {
  junction: string;
  violations: number;
  risk: string;
}

export interface RepeatOffender {
  plate: string;
  score: number;
  count: number;
  lastSeen: string;
  type: string;
}

export interface CommandSummaryResponse {
  generated_at: string;
  period: string;
  kpi: CommandKpi;
  top_junctions: JunctionRanking[];
  repeat_offenders: RepeatOffender[];
  ai_recommendations: AiRecommendation[];
}

export async function getModelHealth(): Promise<ModelHealthResponse> {
  const response = await fetch(`${API_BASE}/debug/models`);
  return handleResponse<ModelHealthResponse>(response);
}

export async function getHotspots(): Promise<HotspotsResponse> {
  const response = await fetch(`${API_BASE}/predict/hotspots`);
  return handleResponse<HotspotsResponse>(response);
}

export async function getFleetSummary(): Promise<FleetSummaryResponse> {
  const response = await fetch(`${API_BASE}/fleet/summary`);
  return handleResponse<FleetSummaryResponse>(response);
}

export async function getCommandSummary(): Promise<CommandSummaryResponse> {
  const response = await fetch(`${API_BASE}/command/summary`);
  return handleResponse<CommandSummaryResponse>(response);
}

